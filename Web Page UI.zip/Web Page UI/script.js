
/* =====================================
   1. GET HTML ELEMENTS
===================================== */

const studentRole = document.getElementById("student-role");
const teacherRole = document.getElementById("teacher-role");

const loginForm = document.getElementById("login-form");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");

const emailError = document.getElementById("email-error");
const passwordError = document.getElementById("password-error");

const togglePassword = document.getElementById("toggle-password");
const formMessage = document.getElementById("form-message");
const forgotPassword = document.getElementById("forgot-password");


/* =====================================
   2. SELECT STUDENT OR TEACHER
===================================== */

let selectedRole = "Student";

function selectRole(role) {
    selectedRole = role;

    studentRole.classList.toggle("active", role === "Student");
    teacherRole.classList.toggle("active", role === "Teacher");

    studentRole.setAttribute(
        "aria-pressed",
        role === "Student"
    );

    teacherRole.setAttribute(
        "aria-pressed",
        role === "Teacher"
    );

    formMessage.textContent = "";
}

studentRole.addEventListener("click", function () {
    selectRole("Student");
});

teacherRole.addEventListener("click", function () {
    selectRole("Teacher");
});


/* =====================================
   3. EMAIL VALIDATION
===================================== */

function validateEmail() {
    const email = emailInput.value.trim();

    emailError.textContent = "";

    if (email === "") {
        emailError.textContent = "Please enter your email address.";
        return false;
    }

    // Suggest adding @ if it is missing
    if (!email.includes("@")) {
        emailError.textContent =
            "Your email is missing '@'. Example: " +
            email + "@gmail.com";

        return false;
    }

    const parts = email.split("@");

    // Check that there is only one @
    if (parts.length !== 2) {
        emailError.textContent =
            "Please enter a valid email address.";

        return false;
    }

    const username = parts[0];
    const domain = parts[1];

    if (username === "" || domain === "") {
        emailError.textContent =
            "Please complete your email address.";

        return false;
    }

    // Suggest adding a domain extension
    if (!domain.includes(".")) {
        emailError.textContent =
            "Your email domain looks incomplete. " +
            "Example: " + username + "@" + domain + ".com";

        return false;
    }

    // Basic email format check
    const emailPattern =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(email)) {
        emailError.textContent =
            "Please check your email format. " +
            "Example: student@example.com";

        return false;
    }

    // Check for a common typing mistake
    if (domain.endsWith(".")) {
        emailError.textContent =
            "Please add a domain extension, such as .com.";

        return false;
    }

    return true;
}

// Validate email while the user types
emailInput.addEventListener("input", function () {
    validateEmail();
});


/* =====================================
   4. PASSWORD VALIDATION
===================================== */

function validatePassword() {
    const password = passwordInput.value;

    passwordError.textContent = "";

    if (password === "") {
        passwordError.textContent =
            "Please enter your password.";

        return false;
    }

    // Check minimum length
    if (password.length < 8) {
        passwordError.textContent =
            "Password must contain at least 8 characters.";

        return false;
    }

    // Check uppercase letter
    if (!/[A-Z]/.test(password)) {
        passwordError.textContent =
            "Add at least one uppercase letter (A-Z).";

        return false;
    }

    // Check lowercase letter
    if (!/[a-z]/.test(password)) {
        passwordError.textContent =
            "Add at least one lowercase letter (a-z).";

        return false;
    }

    // Check number
    if (!/[0-9]/.test(password)) {
        passwordError.textContent =
            "Add at least one number (0-9).";

        return false;
    }

    // Check special character
    if (!/[^A-Za-z0-9]/.test(password)) {
        passwordError.textContent =
            "Add a special character, such as @, #, or !.";

        return false;
    }

    return true;
}

// Validate password while the user types
passwordInput.addEventListener("input", function () {
    validatePassword();
});


/* =====================================
   5. SHOW OR HIDE PASSWORD
===================================== */

togglePassword.addEventListener("click", function () {
    const isPasswordHidden =
        passwordInput.type === "password";

    if (isPasswordHidden) {
        passwordInput.type = "text";

        togglePassword.innerHTML =
            '<i class="fa-regular fa-eye-slash"></i>';

        togglePassword.setAttribute(
            "aria-label",
            "Hide password"
        );
    } else {
        passwordInput.type = "password";

        togglePassword.innerHTML =
            '<i class="fa-regular fa-eye"></i>';

        togglePassword.setAttribute(
            "aria-label",
            "Show password"
        );
    }
});


/* =====================================
   6. LOGIN FORM SUBMISSION
===================================== */

loginForm.addEventListener("submit", function (event) {
    // Prevent the page from refreshing
    event.preventDefault();

    formMessage.textContent = "";
    formMessage.style.color = "#d93025";

    // Validate both fields
    const emailIsValid = validateEmail();
    const passwordIsValid = validatePassword();

    if (!emailIsValid || !passwordIsValid) {
        formMessage.textContent =
            "Please correct the errors above.";

        return;
    }

    // Frontend validation passed
    formMessage.style.color = "#247a45";

    formMessage.textContent =
        selectedRole +
        " login details passed validation. " +
        "Connect the authentication backend to sign in.";

    console.log("Selected role:", selectedRole);
    console.log("Email:", emailInput.value.trim());
    console.log("Remember me:",
        document.getElementById("remember-me").checked
    );
});


/* =====================================
   7. FORGOT PASSWORD
===================================== */

forgotPassword.addEventListener("click", function (event) {
    event.preventDefault();

    formMessage.style.color = "#285da8";

    formMessage.textContent =
        "Password recovery will be available " +
        "after the recovery feature is connected.";
});
