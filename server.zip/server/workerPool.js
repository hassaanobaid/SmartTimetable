// THREADS: runs the scheduler in worker threads so the web server stays responsive,
// and runs several strategies AT THE SAME TIME (one thread per strategy).
// The best result wins: most classes placed, then fewest gaps, then fastest.
const path = require('path');
const { Worker } = require('worker_threads');

const WORKER_FILE = path.join(__dirname, 'workers', 'scheduleWorker.js');
const TIMEOUT_MS = 45000;

// Start ONE thread for one strategy. Resolves with that thread's result.
function runInWorker(input, strategy) {
  return new Promise((resolve, reject) => {
    const worker = new Worker(WORKER_FILE, { workerData: { ...input, strategy } });
    const timer = setTimeout(() => { worker.terminate(); reject(new Error(`Thread for "${strategy}" took too long`)); }, TIMEOUT_MS);
    worker.once('message', (msg) => { clearTimeout(timer); resolve(msg); });
    worker.once('error', (err) => { clearTimeout(timer); reject(err); });
    worker.once('exit', (code) => { clearTimeout(timer); if (code !== 0) reject(new Error(`Thread for "${strategy}" stopped (code ${code})`)); });
  });
}

const better = (a, b) => (a.placed !== b.placed ? a.placed > b.placed : a.gaps !== b.gaps ? a.gaps < b.gaps : a.ms <= b.ms);

// Start one thread per strategy, wait for all of them, return the winner plus a report of every thread.
async function runParallel(input, strategies = ['backtracking', 'greedy']) {
  const settled = await Promise.allSettled(strategies.map((s) => runInWorker(input, s)));
  const results = settled.filter((r) => r.status === 'fulfilled').map((r) => r.value);
  if (!results.length) throw (settled[0].reason || new Error('All scheduling threads failed'));
  const winner = results.reduce((best, r) => (better(r, best) ? r : best));
  const threads = results.map((r) => ({ strategy: r.strategy, threadId: r.threadId, placed: r.placed, total: r.total, gaps: r.gaps, steps: r.steps, ms: r.ms }));
  return { winner, threads };
}

module.exports = { runInWorker, runParallel };
