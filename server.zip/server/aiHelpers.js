// Helper functions for the AI features.
// They only work on plain data (no database or network), so they are easy to test: npm test
const DAY_ORDER = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

const hhmm = (t) => String(t).slice(0, 5);
const slotLabel = (s) => `${s.day} ${hhmm(s.start_time)}-${hhmm(s.end_time)}`;

// "08:30" -> 510 minutes. Returns null when the text is not a valid time.
function toMin(t) {
  const m = /^(\d{1,2}):(\d{2})/.exec(String(t == null ? '' : t).trim());
  if (!m) return null;
  const h = Number(m[1]), mi = Number(m[2]);
  return h > 23 || mi > 59 ? null : h * 60 + mi;
}

const sortSlots = (slots) =>
  [...slots].sort((a, b) => DAY_ORDER.indexOf(a.day) - DAY_ORDER.indexOf(b.day) || toMin(a.start_time) - toMin(b.start_time));

// ---------- 1. Automatic checks on the data (facts the AI can rely on) ----------
function diagnose({ courses, rooms, sections, slots, unavailable, entries }) {
  const issues = [];
  const secSize = new Map(sections.map((s) => [s.id, s.size]));
  const labs = rooms.filter((r) => r.is_lab);
  const normal = rooms.filter((r) => !r.is_lab);

  for (const c of courses) {
    const size = secSize.get(c.section_id) || 0;
    const pool = c.is_lab ? labs : normal;
    const kind = c.is_lab ? 'lab' : 'normal';
    if (!pool.length) issues.push(`${c.code} (${c.section_name}) needs a ${kind} room but none exists.`);
    else if (!pool.some((r) => r.capacity >= size))
      issues.push(`${c.code} (${c.section_name}): no ${kind} room fits ${size} students (largest has ${Math.max(...pool.map((r) => r.capacity))}).`);
  }

  const teacherLoad = new Map();
  const sectionLoad = new Map();
  for (const c of courses) {
    const t = teacherLoad.get(c.teacher_id) || { name: c.teacher_name, n: 0 };
    t.n += c.classes_per_week; teacherLoad.set(c.teacher_id, t);
    const s = sectionLoad.get(c.section_id) || { name: c.section_name, n: 0 };
    s.n += c.classes_per_week; sectionLoad.set(c.section_id, s);
  }
  for (const [tid, t] of teacherLoad) {
    const free = slots.length - ((unavailable.get(tid) || new Set()).size);
    if (t.n > free) issues.push(`${t.name} must teach ${t.n} classes a week but has only ${free} available slots.`);
  }
  for (const s of sectionLoad.values())
    if (s.n > slots.length) issues.push(`Section ${s.name} has ${s.n} classes a week but only ${slots.length} time slots exist.`);

  if (entries.length) {
    const placed = new Map();
    for (const e of entries) placed.set(e.course_id, (placed.get(e.course_id) || 0) + 1);
    for (const c of courses) {
      const p = placed.get(c.id) || 0;
      if (p < c.classes_per_week) issues.push(`${c.code} (${c.section_name}) has only ${p} of ${c.classes_per_week} classes in the timetable.`);
    }
  }
  return issues;
}

// ---------- 2. Text description of the whole department, sent to the AI ----------
function buildContext(d) {
  const { sections, rooms, teachers, courses, slots, unavailable, entries } = d;
  const slotById = new Map(slots.map((s) => [s.id, s]));
  const L = [];

  L.push('SECTIONS: ' + (sections.map((s) => `${s.name} (${s.size} students)`).join('; ') || 'none'));
  L.push('ROOMS: ' + (rooms.map((r) => `${r.name} (capacity ${r.capacity}, ${r.is_lab ? 'lab' : 'classroom'})`).join('; ') || 'none'));

  const byDay = new Map();
  for (const s of sortSlots(slots)) {
    if (!byDay.has(s.day)) byDay.set(s.day, []);
    byDay.get(s.day).push(`${hhmm(s.start_time)}-${hhmm(s.end_time)}`);
  }
  L.push('TIME SLOTS: ' + ([...byDay].map(([day, t]) => `${day}: ${t.join(', ')}`).join(' | ') || 'none'));

  L.push('TEACHERS:');
  for (const t of teachers) {
    const labels = sortSlots([...(unavailable.get(t.id) || [])].map((id) => slotById.get(id)).filter(Boolean)).map(slotLabel);
    const shown = labels.length > 12 ? labels.slice(0, 12).join(', ') + `, and ${labels.length - 12} more` : labels.join(', ');
    L.push(`- ${t.name}${t.department ? ' (' + t.department + ')' : ''}; not available: ${shown || 'never blocked'}`);
  }

  L.push('COURSES:');
  for (const c of courses)
    L.push(`- ${c.code} ${c.name} | section ${c.section_name} | teacher ${c.teacher_name} | ${c.classes_per_week} classes/week | ${c.is_lab ? 'lab' : 'theory'}`);

  if (!entries.length) L.push('TIMETABLE: not generated yet.');
  else {
    L.push(`TIMETABLE (${entries.length} classes placed):`);
    const sorted = [...entries].sort((a, b) =>
      String(a.section_name).localeCompare(String(b.section_name)) ||
      DAY_ORDER.indexOf(a.day) - DAY_ORDER.indexOf(b.day) || toMin(a.start_time) - toMin(b.start_time));
    for (const e of sorted.slice(0, 300))
      L.push(`${e.section_name} | ${e.day} ${hhmm(e.start_time)}-${hhmm(e.end_time)} | ${e.code} ${e.course_name} | ${e.teacher_name} | ${e.room_name}`);
    if (sorted.length > 300) L.push(`(${sorted.length - 300} more classes not shown)`);
  }

  const issues = diagnose(d);
  L.push('AUTOMATIC CHECKS: ' + (issues.length ? '' : 'no problems found in the data.'));
  issues.forEach((i) => L.push('- ' + i));
  return L.join('\n').slice(0, 30000);
}

// ---------- 3. Turn the AI's answer into safe, checked proposals ----------
const TITLES = /\b(dr|mr|mrs|ms|miss|prof|professor|sir|madam)\b\.?/g;
const normName = (s) => String(s || '').toLowerCase().replace(TITLES, ' ').replace(/[^a-z\s]/g, ' ').replace(/\s+/g, ' ').trim();

function findTeacher(name, teachers) {
  const n = normName(name);
  if (!n) return { error: 'The AI did not give a teacher name.' };
  const exact = teachers.filter((t) => normName(t.name) === n);
  if (exact.length === 1) return { teacher: exact[0] };
  const part = teachers.filter((t) => { const tn = normName(t.name); return tn && (tn.includes(n) || n.includes(tn)); });
  if (exact.length > 1 || part.length > 1) return { error: `"${name}" matches more than one teacher. Use the full name.` };
  if (part.length === 1) return { teacher: part[0] };
  return { error: `No teacher named "${name}" was found.` };
}

function normDay(d) {
  const s = String(d || '').trim().toLowerCase();
  if (s.length < 3) return null;
  return DAY_ORDER.find((x) => x.toLowerCase() === s || x.toLowerCase().slice(0, 3) === s.slice(0, 3)) || null;
}

// A slot is matched when its START time is inside [from, to). No times = the whole day.
function resolveChanges(ai, teachers, slots) {
  const proposals = [];
  const warnings = [];
  const list = ai && Array.isArray(ai.changes) ? ai.changes.slice(0, 10) : [];
  if (!list.length) warnings.push(ai && ai.message ? String(ai.message) : 'No availability change was found in that text.');

  for (const ch of list) {
    const action = ch && (ch.action === 'available' || ch.action === 'unavailable') ? ch.action : null;
    if (!action) { warnings.push('Skipped a change with an unclear action.'); continue; }
    const found = findTeacher(ch.teacher, teachers);
    if (found.error) { warnings.push(found.error); continue; }
    const t = found.teacher;

    const days = [...new Set((Array.isArray(ch.days) ? ch.days : []).map(normDay).filter(Boolean))];
    if (!days.length) { warnings.push(`No valid day was given for ${t.name}.`); continue; }

    const blank = (v) => v == null || v === '';
    const from = blank(ch.from) ? null : toMin(ch.from);
    const to = blank(ch.to) ? null : toMin(ch.to);
    if ((!blank(ch.from) && from === null) || (!blank(ch.to) && to === null)) { warnings.push(`Skipped ${t.name}: the time was not understood.`); continue; }

    const matched = sortSlots(slots).filter((s) => {
      const start = toMin(s.start_time);
      return days.includes(s.day) && (from === null || start >= from) && (to === null || start < to);
    });
    if (!matched.length) { warnings.push(`No time slots matched for ${t.name} (${days.join(', ')}).`); continue; }

    proposals.push({
      teacher_id: t.id, teacher_name: t.name, action,
      slot_ids: matched.map((s) => s.id),
      slots: matched.map((s) => ({ id: s.id, day: s.day, start: hhmm(s.start_time), end: hhmm(s.end_time) })),
    });
  }
  return { proposals, warnings };
}

module.exports = { diagnose, buildContext, resolveChanges, sortSlots, hhmm, toMin };
