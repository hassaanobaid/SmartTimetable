// This file runs INSIDE a separate thread (worker_threads).
// It receives the timetable data, runs one scheduling strategy, and sends the result back.
const { parentPort, workerData, threadId } = require('worker_threads');
const { generate } = require('../scheduler');

const result = generate(workerData);
parentPort.postMessage({ ...result, threadId });
