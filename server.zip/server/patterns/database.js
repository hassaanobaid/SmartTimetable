// DESIGN PATTERN: SINGLETON
// The whole application must share ONE connection pool. Database.getInstance() always
// returns the same object, and `new Database()` a second time is not allowed.
require('dotenv').config();
const mysql = require('mysql2/promise');

class Database {
  static #instance = null;

  constructor() {
    if (Database.#instance) throw new Error('Database is a singleton. Use Database.getInstance()');
    this.pool = mysql.createPool({
      host: process.env.DB_HOST || '127.0.0.1',
      port: Number(process.env.DB_PORT) || 3306,
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'smart_timetable',
      waitForConnections: true,
      connectionLimit: 10,
    });
  }

  static getInstance() {
    if (!Database.#instance) Database.#instance = new Database();
    return Database.#instance;
  }

  // Creates tables added after the first version, so older databases keep working.
  async ensureSchema() {
    await this.pool.query(`
      CREATE TABLE IF NOT EXISTS activity_log (
        id         INT AUTO_INCREMENT PRIMARY KEY,
        user_id    INT NULL,
        user_name  VARCHAR(100) NULL,
        action     VARCHAR(40)  NOT NULL,
        entity     VARCHAR(40)  NOT NULL,
        details    VARCHAR(255) NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`);
  }
}

module.exports = Database;
