// The OBSERVERS of the event bus. Each one reacts to the same events in its own way.
const bus = require('./eventBus');
const pool = require('../db');

// Observer 1: writes every event into the activity_log table (database)
function auditObserver(e) {
  const action = e.event.split(':')[1];
  pool.query('INSERT INTO activity_log (user_id, user_name, action, entity, details) VALUES (?, ?, ?, ?, ?)',
    [e.userId, e.userName, action, e.entity, e.details])
    .catch((err) => console.error('Activity log failed: ' + err.message));
}

// Observer 2: prints a line in the server terminal
function consoleObserver(e) {
  console.log(`[event] ${e.event} | ${e.userName || 'system'} | ${e.entity} | ${e.details}`);
}

function registerObservers() {
  for (const name of bus.EVENTS) {
    bus.on(name, auditObserver);
    bus.on(name, consoleObserver);
  }
}

module.exports = { registerObservers, auditObserver, consoleObserver };
