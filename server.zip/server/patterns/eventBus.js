// DESIGN PATTERN: OBSERVER
// The event bus is the "subject". Routes announce what happened (record:created, timetable:generated ...)
// without knowing who is listening. Observers (patterns/observers.js) subscribe to those events.
const { EventEmitter } = require('events');

class EventBus extends EventEmitter {
  // Convenience: announce an activity done by the logged-in user.
  announce(event, req, entity, details) {
    this.emit(event, {
      event, entity, details: String(details || '').slice(0, 250),
      userId: req && req.user ? req.user.id : null,
      userName: req && req.user ? req.user.name : null,
    });
  }
}

module.exports = new EventBus();
module.exports.EVENTS = ['record:created', 'record:updated', 'record:deleted', 'timetable:generated', 'timetable:cleared',
  'availability:changed', 'user:registered', 'user:login', 'user:profile'];
