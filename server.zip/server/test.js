// Quick self-test (no database needed): npm test
const assert = require('assert');
const { validateEmail, validatePassword, validateName } = require('./validators');
const { generate } = require('./scheduler');

// Email checks
['a@b.com', 'hassaan.obaid@gmail.com', 'x_y+z@uni.edu.pk'].forEach((e) => assert.strictEqual(validateEmail(e), null, e));
['', 'abc', 'abc@', '@gmail.com', 'a@b', 'a b@c.com', 'a@@b.com'].forEach((e) => assert.ok(validateEmail(e), 'should reject ' + e));

// Password checks
assert.deepStrictEqual(validatePassword('Abcd@1234'), []);
assert.ok(validatePassword('abcd@1234').length);   // no capital
assert.ok(validatePassword('ABCD@1234').length);   // no small
assert.ok(validatePassword('Abcdefg@').length);    // no number
assert.ok(validatePassword('Abcd12345').length);   // no special
assert.ok(validatePassword('Ab@1').length);        // too short
// Name checks (alphabets only)
['Hassaan Obaid', 'Dr. Ahmed Khan', "O'Neil", 'Ali-Raza'].forEach((n) => assert.strictEqual(validateName(n), null, n));
['', 'A', 'Ali123', '12345', 'Ali@Khan', '  '].forEach((n) => assert.ok(validateName(n), 'should reject ' + n));
console.log('Validators OK');

// Scheduler check with demo-sized data
const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
const times = [['08:30:00', '10:00:00'], ['10:00:00', '11:30:00'], ['11:30:00', '13:00:00'], ['14:00:00', '15:30:00'], ['15:30:00', '17:00:00']];
let id = 1; const slots = [];
days.forEach((d) => times.forEach(([s, e]) => slots.push({ id: id++, day: d, start_time: s, end_time: e })));
const sections = [{ id: 1, name: 'A', size: 40 }, { id: 2, name: 'B', size: 35 }];
const rooms = [{ id: 1, name: 'R1', capacity: 50, is_lab: 0 }, { id: 2, name: 'R2', capacity: 45, is_lab: 0 }, { id: 3, name: 'R3', capacity: 40, is_lab: 0 }, { id: 4, name: 'L1', capacity: 45, is_lab: 1 }];
let cid = 1; const courses = [];
[1, 2].forEach((sec) => [[1, 3, 0], [2, 3, 0], [3, 2, 0], [4, 1, 1]].forEach(([t, n, lab]) =>
  courses.push({ id: cid++, code: 'C' + t, name: 'Course' + t, classes_per_week: n, is_lab: lab, teacher_id: t, teacher_name: 'T' + t, section_id: sec, section_name: 'S' + sec })));
const unavailable = new Set(slots.filter((s) => s.day === 'Monday').map((s) => `1:${s.id}`));

const r = generate({ courses, rooms, slots, sections, unavailable });
assert.strictEqual(r.unplaced.length, 0);
assert.strictEqual(r.placed, r.total);
const seen = { t: new Set(), s: new Set(), r: new Set() };
const byCourse = new Map(courses.map((c) => [c.id, c])); const slotBy = new Map(slots.map((s) => [s.id, s]));
r.assignments.forEach((a) => {
  const c = byCourse.get(a.course_id);
  for (const [k, key] of [['t', `${c.teacher_id}:${a.slot_id}`], ['s', `${c.section_id}:${a.slot_id}`], ['r', `${a.room_id}:${a.slot_id}`]]) {
    assert.ok(!seen[k].has(key), 'double booking ' + key); seen[k].add(key);
  }
  assert.ok(!unavailable.has(`${c.teacher_id}:${a.slot_id}`), 'teacher unavailable slot used');
  assert.strictEqual(!!rooms.find((x) => x.id === a.room_id).is_lab, !!c.is_lab);
});
console.log(`Scheduler OK: ${r.placed}/${r.total} placed, gaps=${r.gaps}, ${r.ms}ms`);

// Impossible case is reported, not crashed
const bad = generate({ courses: [{ ...courses[0], classes_per_week: 5, is_lab: 1 }], rooms: [rooms[0]], slots, sections, unavailable: new Set() });
assert.ok(bad.unplaced.length > 0);
console.log('Unplaceable case reported OK');

// ---------- AI helper checks ----------
const { diagnose, buildContext, resolveChanges } = require('./aiHelpers');
const teachersList = [{ id: 1, name: 'Dr. Ahmed Khan', department: 'SE' }, { id: 2, name: 'Ms. Sara Ali' }, { id: 3, name: 'Mr. Ali Raza' }];
const t = (id, day, s, e) => ({ id, day, start_time: s + ':00', end_time: e + ':00' });
const aiSlots = [t(1, 'Monday', '08:30', '10:00'), t(2, 'Monday', '10:00', '11:30'), t(3, 'Monday', '11:30', '13:00'), t(4, 'Monday', '14:00', '15:30'), t(5, 'Tuesday', '08:30', '10:00')];

// morning on Monday: start times 08:30, 10:00, 11:30 are inside 00:00-12:00
let res1 = resolveChanges({ changes: [{ teacher: 'Ahmed Khan', action: 'unavailable', days: ['monday'], from: '00:00', to: '12:00' }] }, teachersList, aiSlots);
assert.deepStrictEqual(res1.proposals[0].slot_ids, [1, 2, 3]);
assert.strictEqual(res1.proposals[0].teacher_id, 1);
// no time = whole day; short day name accepted
res1 = resolveChanges({ changes: [{ teacher: 'dr ahmed khan', action: 'unavailable', days: ['Tue'] }] }, teachersList, aiSlots);
assert.deepStrictEqual(res1.proposals[0].slot_ids, [5]);
// unknown teacher, ambiguous teacher, bad action, bad time, no match: all become warnings, nothing crashes
res1 = resolveChanges({ changes: [
  { teacher: 'Nobody', action: 'unavailable', days: ['Monday'] },
  { teacher: 'Ali', action: 'unavailable', days: ['Monday'] },
  { teacher: 'Sara Ali', action: 'delete', days: ['Monday'] },
  { teacher: 'Sara Ali', action: 'available', days: ['Monday'], from: 'noon' },
  { teacher: 'Sara Ali', action: 'available', days: ['Friday'] },
] }, teachersList, aiSlots);
assert.strictEqual(res1.proposals.length, 0);
assert.strictEqual(res1.warnings.length, 5);
assert.ok(resolveChanges({}, teachersList, aiSlots).warnings.length === 1);

// diagnose finds real problems
const probCourses = [{ id: 1, code: 'LAB1', section_id: 1, section_name: 'A', teacher_id: 1, teacher_name: 'Dr. X', classes_per_week: 6, is_lab: 1 }];
const probs = diagnose({ courses: probCourses, rooms: [{ id: 1, name: 'R', capacity: 30, is_lab: 0 }], sections: [{ id: 1, name: 'A', size: 40 }],
  slots: aiSlots, unavailable: new Map([[1, new Set([1, 2])]]), entries: [] });
assert.ok(probs.some((p) => p.includes('needs a lab room')));
assert.ok(probs.some((p) => p.includes('available slots')));
const ctx = buildContext({ courses, rooms, sections, teachers: teachersList, slots, unavailable: new Map(), entries: [] });
assert.ok(ctx.includes('TIMETABLE: not generated yet.') && ctx.includes('SECTIONS: A (40 students)'));
console.log('AI helpers OK');

// ---------- Design pattern checks ----------
(async () => {
  // Strategy + Factory
  const { createStrategy, STRATEGY_NAMES } = require('./scheduler');
  assert.strictEqual(createStrategy('greedy').name, 'greedy');
  assert.strictEqual(createStrategy('backtracking').name, 'backtracking');
  assert.throws(() => createStrategy('nope'));
  for (const name of STRATEGY_NAMES) {
    const out = generate({ courses, rooms, slots, sections, unavailable, strategy: name });
    assert.strictEqual(out.strategy, name);
    assert.ok(out.placed > 0);
  }
  console.log('Strategy + Factory OK');

  // Singleton
  const Database = require('./patterns/database');
  assert.strictEqual(Database.getInstance(), Database.getInstance());
  assert.strictEqual(require('./db'), Database.getInstance().pool);
  assert.throws(() => new Database(), /singleton/);
  await Database.getInstance().pool.end();
  console.log('Singleton OK');

  // Observer
  const bus = require('./patterns/eventBus');
  const seen = [];
  bus.on('record:created', (e) => seen.push(e));
  bus.on('record:created', (e) => seen.push({ second: true }));   // two observers, one event
  bus.announce('record:created', { user: { id: 7, name: 'Admin' } }, 'rooms', 'Added Room 1');
  assert.strictEqual(seen.length, 2);
  assert.strictEqual(seen[0].userName, 'Admin');
  assert.strictEqual(seen[0].entity, 'rooms');
  console.log('Observer OK');

  // Threads: two worker threads run at the same time
  const { runParallel } = require('./workerPool');
  const { winner, threads } = await runParallel({ courses, rooms, slots, sections, unavailable });
  assert.strictEqual(threads.length, 2);
  assert.notStrictEqual(threads[0].threadId, threads[1].threadId);
  assert.strictEqual(winner.placed, winner.total);
  console.log(`Threads OK: ${threads.map((t) => `${t.strategy}@thread${t.threadId}=${t.placed}/${t.total}`).join(', ')}; winner=${winner.strategy}`);
})().catch((e) => { console.error(e); process.exit(1); });
