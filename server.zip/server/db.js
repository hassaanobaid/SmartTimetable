// Everyone does require('./db') and gets the pool of the Singleton (see patterns/database.js).
const Database = require('./patterns/database');
module.exports = Database.getInstance().pool;
