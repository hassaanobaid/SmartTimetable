// Activity log: filled automatically by the Observer pattern (patterns/observers.js).
const express = require('express');
const pool = require('../db');
const { adminOnly } = require('../middleware/auth');
const router = express.Router();

router.get('/', adminOnly, async (req, res) => {
  try {
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 50, 1), 200);
    const [rows] = await pool.query('SELECT * FROM activity_log ORDER BY id DESC LIMIT ?', [limit]);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.delete('/', adminOnly, async (req, res) => {
  try { await pool.query('DELETE FROM activity_log'); res.json({ ok: true }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
