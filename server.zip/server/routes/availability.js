const express = require('express');
const pool = require('../db');
const { adminOnly } = require('../middleware/auth');
const bus = require('../patterns/eventBus');
const router = express.Router();

// Validate :teacherId before any route runs
router.param('teacherId', (req, res, next, v) => {
  const n = Number(v);
  if (!Number.isInteger(n) || n < 1) return res.status(400).json({ error: 'Invalid teacher id' });
  next();
});

// Slots where the teacher is NOT available
router.get('/:teacherId', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT slot_id FROM teacher_availability WHERE teacher_id = ?', [req.params.teacherId]);
    res.json({ slotIds: rows.map((r) => r.slot_id) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.put('/:teacherId', adminOnly, async (req, res) => {
  if (req.body.slotIds !== undefined && !Array.isArray(req.body.slotIds))
    return res.status(400).json({ error: 'slotIds must be a list' });
  const ids = [...new Set((req.body.slotIds || []).map(Number).filter((n) => Number.isInteger(n) && n > 0))];
  const conn = await pool.getConnection();
  try {
    const [t] = await conn.query('SELECT name FROM teachers WHERE id = ?', [req.params.teacherId]);
    if (!t.length) return res.status(404).json({ error: 'Teacher not found' });   // the finally block releases the connection
    await conn.beginTransaction();
    await conn.query('DELETE FROM teacher_availability WHERE teacher_id = ?', [req.params.teacherId]);
    if (ids.length)
      await conn.query('INSERT INTO teacher_availability (teacher_id, slot_id) VALUES ?', [ids.map((s) => [Number(req.params.teacherId), s])]);
    await conn.commit();
    bus.announce('availability:changed', req, 'availability', `${t[0].name}: ${ids.length} slot(s) marked unavailable`);
    res.json({ ok: true, saved: ids.length });
  } catch (e) {
    try { await conn.rollback(); } catch {}
    if (e.code === 'ER_NO_REFERENCED_ROW_2') return res.status(400).json({ error: 'One of the selected time slots does not exist.' });
    res.status(500).json({ error: e.message });
  } finally { try { conn.release(); } catch {} }
});

module.exports = router;
