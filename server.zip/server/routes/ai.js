// AI routes. The browser talks to Node; Node talks to the Python AI service.
// The API key lives only in ai-service/.env, never in the browser.
const express = require('express');
const pool = require('../db');
const { adminOnly } = require('../middleware/auth');
const { buildContext, resolveChanges, sortSlots, hhmm } = require('../aiHelpers');

const bus = require('../patterns/eventBus');
const router = express.Router();
const AI_URL = (process.env.AI_SERVICE_URL || 'http://127.0.0.1:8000').replace(/\/$/, '');

function httpError(status, message) {
  const e = new Error(message);
  e.status = status;
  return e;
}

async function callAI(path, { method = 'POST', body, timeoutMs = 60000 } = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(AI_URL + path, {
      method, signal: ctrl.signal,
      headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
    });
    let data = null;
    try { data = await res.json(); } catch {}
    if (!res.ok || !data || data.ok === false)
      throw httpError(res.status === 429 ? 429 : 502, (data && data.error) || `The AI service returned an error (${res.status}).`);
    return data;
  } catch (e) {
    if (e.status) throw e;
    if (e.name === 'AbortError') throw httpError(504, 'The AI took too long to answer. Please try again.');
    throw httpError(503, 'The AI service is not running. Open a new terminal, go to the ai-service folder and run: python app.py');
  } finally {
    clearTimeout(timer);
  }
}

async function loadData() {
  const [sections] = await pool.query('SELECT * FROM sections ORDER BY name');
  const [rooms] = await pool.query('SELECT * FROM rooms ORDER BY name');
  const [teachers] = await pool.query('SELECT * FROM teachers ORDER BY name');
  const [slots] = await pool.query('SELECT * FROM time_slots');
  const [courses] = await pool.query(
    `SELECT c.*, t.name AS teacher_name, s.name AS section_name FROM courses c
     JOIN teachers t ON t.id = c.teacher_id JOIN sections s ON s.id = c.section_id ORDER BY s.name, c.code`);
  const [av] = await pool.query('SELECT teacher_id, slot_id FROM teacher_availability');
  const [entries] = await pool.query(
    `SELECT e.course_id, c.code, c.name AS course_name, t.name AS teacher_name, s.name AS section_name,
            r.name AS room_name, ts.day, ts.start_time, ts.end_time
     FROM timetable_entries e JOIN courses c ON c.id = e.course_id JOIN teachers t ON t.id = c.teacher_id
     JOIN sections s ON s.id = c.section_id JOIN rooms r ON r.id = e.room_id JOIN time_slots ts ON ts.id = e.slot_id`);
  const unavailable = new Map();
  for (const a of av) {
    if (!unavailable.has(a.teacher_id)) unavailable.set(a.teacher_id, new Set());
    unavailable.get(a.teacher_id).add(a.slot_id);
  }
  return { sections, rooms, teachers, slots, courses, unavailable, entries };
}

const fail = (res, e) => res.status(e.status || 500).json({ error: e.message });

// Is the AI service running and does it have a key?
router.get('/status', async (req, res) => {
  try {
    const h = await callAI('/health', { method: 'GET', timeoutMs: 4000 });
    res.json({ online: true, provider: h.provider, model: h.model, configured: h.configured });
  } catch (e) {
    res.json({ online: false, error: e.message });
  }
});

// Question about the timetable (any logged-in user)
router.post('/ask', async (req, res) => {
  try {
    const question = String(req.body.question || '').trim();
    if (!question) throw httpError(400, 'Type a question first.');
    if (question.length > 1000) throw httpError(400, 'The question is too long (maximum 1000 characters).');
    const history = (Array.isArray(req.body.history) ? req.body.history : []).slice(-6).map((m) => ({
      role: m && m.role === 'assistant' ? 'assistant' : 'user',
      content: String((m && m.content) || '').slice(0, 2000),
    }));
    const context = buildContext(await loadData());
    const r = await callAI('/ask', { body: { question, context, history } });
    res.json({ answer: r.answer });
  } catch (e) { fail(res, e); }
});

// Plain English -> proposed availability changes (admin only). Nothing is saved here.
router.post('/parse-availability', adminOnly, async (req, res) => {
  try {
    const text = String(req.body.text || '').trim();
    if (!text) throw httpError(400, 'Type what you want to change first.');
    if (text.length > 500) throw httpError(400, 'Please keep it under 500 characters.');
    const [teachers] = await pool.query('SELECT id, name FROM teachers ORDER BY name');
    const [slots] = await pool.query('SELECT * FROM time_slots');
    if (!teachers.length) throw httpError(400, 'Add teachers first (Teachers tab).');
    if (!slots.length) throw httpError(400, 'Add time slots first (Time Slots tab).');

    const r = await callAI('/parse-availability', {
      body: {
        text,
        teachers: teachers.map((t) => t.name),
        days: [...new Set(sortSlots(slots).map((s) => s.day))],
        slots: sortSlots(slots).map((s) => ({ day: s.day, start: hhmm(s.start_time), end: hhmm(s.end_time) })),
      },
    });
    const { proposals, warnings } = resolveChanges(r, teachers, slots);
    res.json({ proposals, warnings });
  } catch (e) { fail(res, e); }
});

// Save the proposals the admin confirmed (admin only)
router.post('/apply-availability', adminOnly, async (req, res) => {
  const changes = Array.isArray(req.body.changes) ? req.body.changes.slice(0, 10) : [];
  if (!changes.length) return res.status(400).json({ error: 'Nothing to apply.' });
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    let added = 0, removed = 0;
    for (const ch of changes) {
      const tid = Number(ch.teacher_id);
      const ids = (Array.isArray(ch.slot_ids) ? ch.slot_ids : []).map(Number).filter(Number.isInteger);
      if (!Number.isInteger(tid) || !ids.length || !['available', 'unavailable'].includes(ch.action)) throw httpError(400, 'Invalid change.');
      const [t] = await conn.query('SELECT id FROM teachers WHERE id = ?', [tid]);
      if (!t.length) throw httpError(400, 'Teacher not found.');
      const [valid] = await conn.query('SELECT id FROM time_slots WHERE id IN (?)', [ids]);
      const ok = valid.map((v) => v.id);
      if (!ok.length) continue;
      if (ch.action === 'unavailable') {
        const [r] = await conn.query('INSERT IGNORE INTO teacher_availability (teacher_id, slot_id) VALUES ?', [ok.map((s) => [tid, s])]);
        added += r.affectedRows;
      } else {
        const [r] = await conn.query('DELETE FROM teacher_availability WHERE teacher_id = ? AND slot_id IN (?)', [tid, ok]);
        removed += r.affectedRows;
      }
    }
    await conn.commit();
    bus.announce('availability:changed', req, 'availability', `AI change applied: ${added} added, ${removed} removed`);
    res.json({ ok: true, added, removed });
  } catch (e) {
    try { await conn.rollback(); } catch {}
    fail(res, e);
  } finally { conn.release(); }
});

module.exports = router;
